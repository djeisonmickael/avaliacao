﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Exe4</title>
<link type="text/css" rel="stylesheet" href="css/style.css" />
<script language="javascript" type="text/javascript" src="js/jquery.js"></script>
<script language="javascript" type="text/javascript" src="js/script.js"></script>
</head>

<body onload="atualizaTarefas();">
	<div id="blocoCentral">
		<div>
			<h2>Gerenciador de Tarefas</h2>
		</div>
		<div id="topo">
			<div id="retorno"></div>
			<a href="#" onclick="exibeCampos();">Adicionar +</a>
		</div>
		<div id="add" style="display:none;">
			<form id="frmAdd" name="frmAdd" method="POST">
				<label>Título</label>
				<input type="text" name="titulo" id="titulo" style="width:15%" maxlength="50">
				<label>Descrição</label>
				<textarea name="descricao" id="descricao" rows="3" style="width:30%"></textarea>
				<label>Prioridade</label>
				<select name="prioridade" id="prioridade">
					<option value="9"> -- </option>
					<option value="0">Alta</option>
					<option value="1">Média</option>
					<option value="2">Baixa</option>
				</select>
				<input type="button" onclick="addTarefa();" value="Add">
				<input type="button" onclick="ocultaCampos();" value="Cancel">
			</form>
		</div>
		<div id="principal"></div>
	</div>

</body>

</html>
