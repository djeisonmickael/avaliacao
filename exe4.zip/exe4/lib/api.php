<?php
header("Content-Type:application/json");

$acao = $_GET['acao'];

switch ($acao){
	case "criar":
		criar();
	break;
	case "excluir":
		excluir();
	break;
	case "atualizar":
		atualizar();
	break;
}
function criar(){
	$parametros = array("titulo" => $_POST['titulo'],"descricao"=>$_POST['descricao'],"prioridade"=>$_POST['prioridade']);
	$parametros = json_encode($parametros);
	
	$api = curl_init('http://localhost:8090/projects/Avaliacao/exe4/lib/add.php');
	curl_setopt($api, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($api, CURLOPT_POSTFIELDS, $parametros);
	curl_setopt($api, CURLOPT_RETURNTRANSFER, true);
	
	$result=curl_exec($api);
	curl_close($api);
	
	$result=json_decode($result);
	
	echo $result;
}