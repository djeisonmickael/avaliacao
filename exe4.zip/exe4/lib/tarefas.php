<?php
include('Conexao.class.php');
echo '<table id="tarefas" border="0">
		<tr>
			<th>Prioridade</th>
			<th>Título</th>
			<th>Descrição</th>
			<th>Ações</th>
		</tr>';

	$conexao = new Conexao();
	$consulta = $conexao->Consulta("select * from tarefas order by prioridade");

	while($result=mysql_fetch_array($consulta)){
		switch($result['prioridade']){
			case 0:
				$prioridade = 'Alta';
				break;
			case 1:
				$prioridade = 'Média';
				break;
			case 2:
				$prioridade = 'Baixa';
				break;
		}
	?>
	<tr rel="<?=$result['id']?>">
		<td><?=$prioridade;?></td>
		<td><?=$result['titulo'];?></td>
		<td><?=$result['descricao'];?></td>
		<td>
			<a href="#" onclick="editar(<?=$result['id']?>);">editar</a>
			&nbsp;
			<a href="#" onclick="excluir(<?=$result['id']?>);">excluir</a>
		</td>
	</tr>
	<?php
	}
	?>
</table>
