<?php
include('Conexao.class.php');

$id = $_GET['id'];

$conexao = new Conexao();
$sql = "delete from tarefas where id = $id";
$excluir = $conexao->Consulta($sql);

if($excluir){
	echo "Tarefa excluída com sucesso!";
}else{
	echo "Erro ao tentar excluir tarefa.";
}
