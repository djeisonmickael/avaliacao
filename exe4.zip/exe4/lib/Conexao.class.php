<?php
class Conexao{
	public $usuario = "root";
	public $senha = "root";
	public $sid = "127.0.0.1";
	public $banco = "prova";
	public $consulta = "";
  	public $link = "";

	function __construct(){
  		$this->Conecta();
  	}

  	public function Conecta(){
        $this->link = mysql_connect($this->sid,$this->usuario,$this->senha);
  		if (!$this->link){
  			die("Problema na Conexao com o Banco de Dados");
  		}elseif (!mysql_select_db($this->banco,$this->link)){
  			die("Problema na Conexao com o Banco de Dados");
		}
  	}

	public function Desconecta(){
		return mysql_close($this->link);
	}

	public function Consulta($consulta){
       	$this->consulta = $consulta;
  		if ($resultado = mysql_query($this->consulta,$this->link)){
  			return $resultado;
		}else{
  			return mysql_error();;
  		}
  		$this->Desconecta();
  	}
}
