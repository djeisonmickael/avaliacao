<?php
include('Conexao.class.php');

$titulo = $_POST['titulo'];
$descricao = $_POST['descricao'];
$prioridade = $_POST['prioridade'];

$conexao = new Conexao();
$sql = "insert into tarefas (titulo,descricao,prioridade) values ('$titulo','$descricao',$prioridade)";
$salva = $conexao->Consulta($sql);

if($salva){
	echo 'Tarefa cadastrada com sucesso!';
}else{
	echo 'Erro ao tentar cadastrar tarefa.';
}
