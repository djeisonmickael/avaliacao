<?php
include('Conexao.class.php');

$id=$_GET['id'];

$conexao = new Conexao();
$retorno = $conexao->Consulta("select * from tarefas where id = $id");
$retorno=mysql_fetch_assoc($retorno);
switch($retorno['prioridade']){
	case 0:
		$prioridade = 'Alta';
		break;
	case 1:
		$prioridade = 'Média';
		break;
	case 2:
		$prioridade = 'Baixa';
		break;
}
?>
<form id="frmUpd" name="frmUpd" method="POST">
	<label>Título</label>
	<input type="text" name="upTitulo" id="upTitulo" style="width:15%" maxlength="50" value="<?=$retorno['titulo'];?>">
	<label>Descrição</label>
	<textarea name="upDescricao" id="upDescricao" rows="3" style="width:30%"><?=$retorno['descricao'];?></textarea>
	<label>Prioridade</label>
	<select name="upPrioridade" id="upPrioridade">
		<option value="<?=$retorno['prioridade'];?>"><?=$prioridade;?></option>
		<option value="0">Alta</option>
		<option value="1">Média</option>
		<option value="2">Baixa</option>
	</select>
	<input type="button" onclick="atualizar(<?=$id;?>);" value="Salvar">
	<input type="button" onclick="ocultaUpd();" value="Cancel">
</form>