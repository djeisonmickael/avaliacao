<?php
include('Conexao.class.php');

$id=$_GET['id'];
$titulo=$_POST['upTitulo'];
$descricao=$_POST['upDescricao'];
$prioridade=$_POST['upPrioridade'];

$conexao = new Conexao();
$sql = "update tarefas set titulo = '$titulo',descricao = '$descricao',prioridade = $prioridade where id=$id";
$atualiza = $conexao->Consulta($sql);

if($atualiza){
	echo "Tarefa atualizada com sucesso!";
}else{
	echo "Erro ao tentar atualizar tarefa.";
}
