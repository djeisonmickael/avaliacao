function exibeCampos(){
	$('#add').attr('style','display:inline');
}

function ocultaCampos(){
	$('#add').attr('style','display:none');
}
function atualizaTarefas(){
	$('#principal').load('lib/tarefas.php');
}
function addTarefa(){
	$.post(
		'lib/add.php',
		$('#frmAdd').serialize(),
		function(result){
			ocultaCampos();
			$('#retorno').html(result)
			$('#frmAdd')[0].reset();
			atualizaTarefas();
		}
	);
}
function excluir(id){
	
	if(confirm("Deseja realmente excluir esta tarefa?")){
		$('#retorno').load('lib/excluir.php?id='+id,function(){
			atualizaTarefas();
		});
	}
}
function editar(id){
	$('#retorno').attr('style','display:block');
	$('#retorno').load('lib/atualizar.php?id='+id);
}
function ocultaUpd(){
	$('#retorno').attr('style','display:none');
}
function atualizar(id){
	$.post(
		'lib/salvar.php?id='+id,
		$('#frmUpd').serialize(),
		function(result){
			$('#retorno').html(result)
			atualizaTarefas();
		}
	);
}